﻿public class LoginModel
{
    public string UserName { get; set; } = "bob";
    public string Password { get; set; } = "bob";
    public string ReturnUrl { get; set; } = "";
}
